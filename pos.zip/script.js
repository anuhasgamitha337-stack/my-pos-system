/**
 * POS & Inventory – OFFLINE backend (IndexedDB)
 * Drop-in replacement for the Google Apps Script backend.
 * It exposes window.posCall(fn, ...args), which the HTML uses instead of google.script.run.
 * Every original server function (checkout, FIFO batches, cancel/return, profit, expenses ...) is ported 1:1.
 */
(function () {
  'use strict';
  const DB_NAME = 'pos_inventory_offline', DB_VER = 1;
  const SCHEMA = {
    Products: ['id', 'name', 'category', 'sku', 'price', 'cost', 'stock', 'reorderLevel', 'active'],
    Customers: ['id', 'name', 'phone', 'email', 'address', 'balance', 'totalSpent', 'createdAt'],
    Suppliers: ['id', 'name', 'phone', 'email', 'address'],
    Sales: ['saleId', 'date', 'customerId', 'customerName', 'subtotal', 'discount', 'tax', 'total', 'paid', 'due', 'method', 'status', 'statusDate', 'statusNote', 'refund'],
    SaleItems: ['saleId', 'productId', 'name', 'qty', 'price', 'lineTotal', 'cogs'],
    Purchases: ['grnId', 'date', 'supplierId', 'supplierName', 'productId', 'productName', 'qty', 'unitCost', 'total', 'reference'],
    StockMovements: ['date', 'productId', 'productName', 'type', 'qty', 'before', 'after', 'reference'],
    Payments: ['date', 'customerId', 'customerName', 'amount', 'method', 'balanceAfter'],
    Batches: ['batchId', 'productId', 'productName', 'date', 'qtyReceived', 'qtyRemaining', 'unitCost', 'ref'],
    SaleBatches: ['saleId', 'productId', 'batchId', 'qty', 'unitCost', 'cost'],
    Categories: ['name'],
    Expenses: ['id', 'date', 'category', 'description', 'amount', 'createdAt']
  };
  const DEFAULT_EXPENSE_CATEGORIES = ['Rent', 'Utilities', 'Salaries', 'Transport', 'Marketing', 'Tea/Refreshments', 'Other'];

  /* ---------- IndexedDB layer ---------- */
  let db = null, cache = {}, seq = {}, pend = [], queue = Promise.resolve();

  function openDB() {
    return new Promise((res, rej) => {
      if (!window.indexedDB) return rej(new Error('This browser does not support IndexedDB'));
      const r = indexedDB.open(DB_NAME, DB_VER);
      r.onupgradeneeded = () => { const d = r.result; Object.keys(SCHEMA).forEach(n => { if (!d.objectStoreNames.contains(n)) d.createObjectStore(n, { keyPath: '_row' }); }); };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  }
  function loadAll() {
    return new Promise((res, rej) => {
      const names = Object.keys(SCHEMA), t = db.transaction(names, 'readonly'), out = {};
      names.forEach(n => { t.objectStore(n).getAll().onsuccess = e => { out[n] = e.target.result.sort((a, b) => a._row - b._row); }; });
      t.oncomplete = () => {
        cache = out; seq = {};
        names.forEach(n => { seq[n] = cache[n].reduce((m, r) => Math.max(m, r._row), 0); });
        res();
      };
      t.onerror = () => rej(t.error);
    });
  }
  function commit(ops) {
    if (!ops.length) return Promise.resolve();
    return new Promise((res, rej) => {
      const names = [...new Set(ops.map(o => o[1]))], t = db.transaction(names, 'readwrite');
      ops.forEach(o => { const s = t.objectStore(o[1]); if (o[0] === 'put') s.put(o[2]); else s.delete(o[2]); });
      t.oncomplete = () => res();
      t.onerror = t.onabort = () => rej(t.error || new Error('Could not save to local storage'));
    });
  }
  const ready = openDB().then(d => { db = d; return loadAll(); }).then(() => {
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
  });

  /* Run fn as one atomic unit: all writes are committed together, or nothing is kept. */
  function tx(fn) {
    const job = queue.then(async () => {
      await ready;
      pend = [];
      try { const r = fn(); await commit(pend); pend = []; return r; }
      catch (e) { pend = []; await loadAll(); throw e; }
    });
    queue = job.catch(() => {});
    return job;
  }

  /* ---------- Sheet-like helpers (same names as the Apps Script version) ---------- */
  const pad = n => String(n).padStart(2, '0');
  const ymd_ = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const now_ = () => { const d = new Date(); return ymd_(d) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()); };
  const round2_ = n => Math.round((Number(n) || 0) * 100) / 100;
  const rows_ = name => cache[name].map(r => Object.assign({}, r));
  const full_ = (name, o) => { const rec = {}; SCHEMA[name].forEach(c => { rec[c] = (o[c] === undefined || o[c] === null) ? '' : o[c]; }); return rec; };
  function append_(name, objs) {
    objs.forEach(o => { const rec = full_(name, o); rec._row = ++seq[name]; cache[name].push(rec); pend.push(['put', name, Object.assign({}, rec)]); });
  }
  function find_(name, rowNo) { return cache[name].find(r => r._row === rowNo); }
  function writeRow_(name, rowNo, obj) {
    const rec = find_(name, rowNo); Object.assign(rec, full_(name, obj)); pend.push(['put', name, Object.assign({}, rec)]);
  }
  function setCell_(name, rowNo, key, value) {
    const rec = find_(name, rowNo); rec[key] = value; pend.push(['put', name, Object.assign({}, rec)]);
  }
  function deleteRow_(name, rowNo) {
    cache[name] = cache[name].filter(r => r._row !== rowNo); pend.push(['del', name, rowNo]);
  }
  function nextId_(name, prefix, p) {
    let max = 0;
    cache[name].forEach(r => { const n = parseInt(String(r[SCHEMA[name][0]]).slice(prefix.length), 10); if (n > max) max = n; });
    return prefix + String(max + 1).padStart(p, '0');
  }
  const clean_ = o => { const c = {}; Object.keys(o).forEach(k => { if (k !== '_row') c[k] = o[k]; }); return c; };
  const strip_ = arr => arr.map(clean_);
  const isActive_ = p => p.active !== false && String(p.active).toUpperCase() !== 'FALSE';
  const isLive_ = s => !s.status || s.status === 'Completed';
  const logMove_ = (p, type, qty, before, after, ref) => ({ date: now_(), productId: p.id, productName: p.name, type: type, qty: qty, before: before, after: after, reference: ref || '' });

  /* ---------- FIFO batch engine ---------- */
  function fifoCtx_() {
    const rows = rows_('Batches'), byProd = {}; let max = 0;
    rows.forEach(b => {
      const n = parseInt(String(b.batchId).slice(1), 10); if (n > max) max = n;
      b.qtyRemaining = Number(b.qtyRemaining) || 0; b.unitCost = Number(b.unitCost) || 0;
      (byProd[b.productId] = byProd[b.productId] || []).push(b);
    });
    Object.keys(byProd).forEach(k => byProd[k].sort((a, b) => a.date < b.date ? -1 : a.date > b.date ? 1 : a._row - b._row));
    return { byProd: byProd, next: max + 1, added: [], dirty: {} };
  }
  const remaining_ = (ctx, pid) => (ctx.byProd[pid] || []).reduce((a, b) => a + b.qtyRemaining, 0);
  function addBatch_(ctx, p, qty, cost, ref, date) {
    const b = { batchId: 'B' + String(ctx.next++).padStart(5, '0'), productId: p.id, productName: p.name, date: date || now_(), qtyReceived: qty, qtyRemaining: qty, unitCost: round2_(cost), ref: ref || '' };
    (ctx.byProd[p.id] = ctx.byProd[p.id] || []).push(b); ctx.added.push(b); return b;
  }
  function syncBatches_(ctx, p) {
    const gap = Number(p.stock) - remaining_(ctx, p.id);
    if (gap > 0.0001) addBatch_(ctx, p, gap, Number(p.cost) || 0, (ctx.byProd[p.id] || []).length ? 'RECONCILE' : 'OPENING');
  }
  function consume_(ctx, pid, qty) {
    const alloc = []; let need = qty;
    (ctx.byProd[pid] || []).forEach(b => {
      if (need <= 0 || b.qtyRemaining <= 0) return;
      const take = Math.min(b.qtyRemaining, need);
      b.qtyRemaining -= take; need -= take;
      if (b._row) ctx.dirty[b.batchId] = b;
      alloc.push({ batchId: b.batchId, qty: take, unitCost: b.unitCost, cost: take * b.unitCost });
    });
    return { alloc: alloc, short: need };
  }
  function flush_(ctx) {
    Object.keys(ctx.dirty).forEach(k => setCell_('Batches', ctx.dirty[k]._row, 'qtyRemaining', ctx.dirty[k].qtyRemaining));
    append_('Batches', ctx.added);
  }

  /* ---------- API (same names/arguments as the Apps Script functions) ---------- */
  const API = {};

  API.getInitialData = () => ({
    products: strip_(rows_('Products').filter(isActive_)),
    customers: strip_(rows_('Customers')),
    suppliers: strip_(rows_('Suppliers')),
    purchases: strip_(rows_('Purchases').slice(-40).reverse())
  });

  API.getDashboard = () => {
    const today = ymd_(new Date()), month = today.slice(0, 7);
    const allSales = rows_('Sales'), sales = allSales.filter(isLive_);
    const sum = list => ({ total: round2_(list.reduce((a, s) => a + Number(s.total || 0), 0)), count: list.length });
    const products = rows_('Products').filter(isActive_), customers = rows_('Customers');
    return {
      today: sum(sales.filter(s => String(s.date).slice(0, 10) === today)),
      month: sum(sales.filter(s => String(s.date).slice(0, 7) === month)),
      lowStock: strip_(products.filter(p => Number(p.stock) <= Number(p.reorderLevel || 0))),
      productCount: products.length, customerCount: customers.length,
      outstanding: round2_(customers.reduce((a, c) => a + Number(c.balance || 0), 0)),
      recent: strip_(allSales.slice(-10).reverse())
    };
  };

  API.saveProduct = p => tx(() => {
    if (!p || !String(p.name || '').trim()) throw new Error('Product name is required');
    const price = Number(p.price), cost = Number(p.cost || 0), stock = Number(p.stock || 0), rl = Number(p.reorderLevel || 0);
    if (!(price >= 0) || cost < 0 || stock < 0 || rl < 0) throw new Error('Price, cost, stock and reorder level must be valid numbers');
    const rec = { name: String(p.name).trim(), category: String(p.category || '').trim(), sku: String(p.sku || '').trim(), price: price, cost: cost, stock: stock, reorderLevel: rl, active: true };
    const ctx = fifoCtx_();
    if (p.id) {
      const old = rows_('Products').find(r => r.id === p.id);
      if (!old) throw new Error('Product not found');
      rec.id = old.id;
      const oldStock = Number(old.stock);
      if (oldStock !== stock) {
        syncBatches_(ctx, old);
        const diff = stock - oldStock;
        if (diff > 0) addBatch_(ctx, rec, diff, cost, 'ADJUST'); else consume_(ctx, old.id, -diff);
      }
      writeRow_('Products', old._row, rec);
      if (oldStock !== stock) append_('StockMovements', [logMove_(rec, 'ADJUST', stock - oldStock, oldStock, stock, 'Manual edit')]);
    } else {
      rec.id = nextId_('Products', 'P', 4);
      append_('Products', [rec]);
      if (stock > 0) {
        addBatch_(ctx, rec, stock, cost, 'OPENING');
        append_('StockMovements', [logMove_(rec, 'OPENING', stock, 0, stock, 'New product')]);
      }
    }
    flush_(ctx);
    return { ok: true, id: rec.id };
  });

  API.deleteProduct = id => tx(() => {
    const p = rows_('Products').find(r => r.id === id);
    if (!p) throw new Error('Product not found');
    setCell_('Products', p._row, 'active', false);
    return { ok: true };
  });

  API.saveCustomer = c => tx(() => {
    if (!c || !String(c.name || '').trim()) throw new Error('Customer name is required');
    const rec = { name: String(c.name).trim(), phone: String(c.phone || '').trim(), email: String(c.email || '').trim(), address: String(c.address || '').trim() };
    if (c.id) {
      const old = rows_('Customers').find(r => r.id === c.id);
      if (!old) throw new Error('Customer not found');
      writeRow_('Customers', old._row, Object.assign({}, old, rec));
      return { ok: true, id: old.id };
    }
    rec.id = nextId_('Customers', 'C', 4); rec.balance = 0; rec.totalSpent = 0; rec.createdAt = now_();
    append_('Customers', [rec]);
    return { ok: true, id: rec.id };
  });

  API.saveSupplier = s => tx(() => {
    if (!s || !String(s.name || '').trim()) throw new Error('Supplier name is required');
    const rec = { name: String(s.name).trim(), phone: String(s.phone || '').trim(), email: String(s.email || '').trim(), address: String(s.address || '').trim() };
    if (s.id) {
      const old = rows_('Suppliers').find(r => r.id === s.id);
      if (!old) throw new Error('Supplier not found');
      rec.id = old.id; writeRow_('Suppliers', old._row, rec);
    } else { rec.id = nextId_('Suppliers', 'S', 4); append_('Suppliers', [rec]); }
    return { ok: true, id: rec.id };
  });

  API.getCustomerHistory = id => ({
    sales: strip_(rows_('Sales').filter(s => s.customerId === id).reverse()),
    payments: strip_(rows_('Payments').filter(p => p.customerId === id).reverse())
  });

  API.settleBalance = (customerId, amount, method) => tx(() => {
    amount = round2_(amount);
    const c = rows_('Customers').find(r => r.id === customerId);
    if (!c) throw new Error('Customer not found');
    if (!(amount > 0)) throw new Error('Enter an amount greater than zero');
    if (amount > Number(c.balance) + 0.001) throw new Error('Amount exceeds outstanding balance');
    const bal = round2_(Number(c.balance) - amount);
    setCell_('Customers', c._row, 'balance', bal);
    append_('Payments', [{ date: now_(), customerId: c.id, customerName: c.name, amount: amount, method: method || 'Cash', balanceAfter: bal }]);
    return { ok: true, balance: bal };
  });

  API.checkout = req => tx(() => {
    if (!req || !req.items || !req.items.length) throw new Error('Cart is empty');
    const prods = rows_('Products'), byId = {};
    prods.forEach(p => byId[p.id] = p);
    const ctx = fifoCtx_(), lines = [], moves = [], allocs = [];
    let subtotal = 0;
    const saleId = nextId_('Sales', 'INV-', 5), date = now_();

    req.items.forEach(i => {
      const p = byId[i.id], qty = Math.floor(Number(i.qty));
      if (!p || !isActive_(p)) throw new Error('Product no longer available: ' + i.id);
      if (!(qty > 0)) throw new Error('Invalid quantity for ' + p.name);
      if (Number(p.stock) < qty) throw new Error('Insufficient stock for ' + p.name + ' (available: ' + p.stock + ')');
      syncBatches_(ctx, p);
      const before = Number(p.stock); p.stock = before - qty;
      const fifo = consume_(ctx, p.id, qty); let cogs = 0;
      fifo.alloc.forEach(a => { cogs += a.cost; allocs.push({ saleId: saleId, productId: p.id, batchId: a.batchId, qty: a.qty, unitCost: a.unitCost, cost: round2_(a.cost) }); });
      if (fifo.short > 0) cogs += fifo.short * (Number(p.cost) || 0);
      const lineTotal = round2_(Number(p.price) * qty); subtotal += lineTotal;
      lines.push({ saleId: saleId, productId: p.id, name: p.name, qty: qty, price: Number(p.price), lineTotal: lineTotal, cogs: round2_(cogs) });
      moves.push(logMove_(p, 'SALE', -qty, before, p.stock, saleId));
    });

    subtotal = round2_(subtotal);
    const discount = Math.min(Math.max(round2_(req.discount), 0), subtotal);
    const taxRate = Math.max(Number(req.taxRate) || 0, 0);
    const tax = round2_((subtotal - discount) * taxRate / 100);
    const total = round2_(subtotal - discount + tax);
    const paid = Math.min(Math.max(round2_(req.paid), 0), total);
    const due = round2_(total - paid);

    let cust = null;
    if (req.customerId) { cust = rows_('Customers').find(c => c.id === req.customerId); if (!cust) throw new Error('Customer not found'); }
    else if (due > 0) throw new Error('Select a registered customer to sell on credit');

    Object.keys(byId).forEach(id => { if (lines.some(l => l.productId === id)) setCell_('Products', byId[id]._row, 'stock', byId[id].stock); });
    flush_(ctx);
    const sale = { saleId: saleId, date: date, customerId: cust ? cust.id : '', customerName: cust ? cust.name : 'Walk-in', subtotal: subtotal, discount: discount, tax: tax, total: total, paid: paid, due: due, method: req.method || 'Cash', status: 'Completed' };
    append_('Sales', [sale]); append_('SaleItems', lines); append_('SaleBatches', allocs); append_('StockMovements', moves);
    if (cust) {
      setCell_('Customers', cust._row, 'balance', round2_(Number(cust.balance) + due));
      setCell_('Customers', cust._row, 'totalSpent', round2_(Number(cust.totalSpent) + total));
    }
    const items = lines.map(l => ({ saleId: l.saleId, productId: l.productId, name: l.name, qty: l.qty, price: l.price, lineTotal: l.lineTotal }));
    return { ok: true, sale: sale, items: items, taxRate: taxRate };
  });

  API.savePurchase = req => tx(() => {
    if (!req || !req.items || !req.items.length) throw new Error('Add at least one item');
    const sup = rows_('Suppliers').find(s => s.id === req.supplierId);
    if (!sup) throw new Error('Select a supplier');
    const byId = {}; rows_('Products').forEach(p => byId[p.id] = p);
    const ctx = fifoCtx_(), grnId = nextId_('Purchases', 'GRN-', 5), date = now_(), recs = [], moves = [];
    req.items.forEach(i => {
      const p = byId[i.productId], qty = Math.floor(Number(i.qty)), cost = round2_(i.unitCost);
      if (!p) throw new Error('Product not found: ' + i.productId);
      if (!(qty > 0)) throw new Error('Invalid quantity for ' + p.name);
      if (!(cost >= 0)) throw new Error('Invalid cost for ' + p.name);
      syncBatches_(ctx, p);
      const before = Number(p.stock);
      addBatch_(ctx, p, qty, cost, grnId, date);
      p.stock = before + qty; p.cost = cost;
      recs.push({ grnId: grnId, date: date, supplierId: sup.id, supplierName: sup.name, productId: p.id, productName: p.name, qty: qty, unitCost: cost, total: round2_(qty * cost), reference: req.reference || '' });
      moves.push(logMove_(p, 'PURCHASE', qty, before, p.stock, grnId));
    });
    Object.keys(byId).forEach(id => {
      if (recs.some(r => r.productId === id)) { setCell_('Products', byId[id]._row, 'stock', byId[id].stock); setCell_('Products', byId[id]._row, 'cost', byId[id].cost); }
    });
    flush_(ctx); append_('Purchases', recs); append_('StockMovements', moves);
    return { ok: true, grnId: grnId };
  });

  API.getProfitReport = (from, to) => {
    from = String(from || '').slice(0, 10); to = String(to || '').slice(0, 10);
    if (!from || !to || from > to) throw new Error('Choose a valid date range');
    const inRange = d => { const k = String(d).slice(0, 10); return k >= from && k <= to; };
    const sales = rows_('Sales').filter(s => inRange(s.date) && isLive_(s)), saleDate = {};
    let revenue = 0, discount = 0, tax = 0;
    sales.forEach(s => { saleDate[s.saleId] = String(s.date); revenue += Number(s.subtotal || 0) - Number(s.discount || 0); discount += Number(s.discount || 0); tax += Number(s.tax || 0); });

    const curCost = {}; rows_('Products').forEach(p => curCost[p.id] = Number(p.cost) || 0);
    const hist = {};
    rows_('Purchases').forEach(p => (hist[p.productId] = hist[p.productId] || []).push({ d: String(p.date), c: Number(p.unitCost) || 0 }));
    Object.keys(hist).forEach(k => hist[k].sort((a, b) => (a.d < b.d ? -1 : a.d > b.d ? 1 : 0)));
    const costAt = (pid, d) => { let c = null; (hist[pid] || []).some(e => { if (e.d <= d) { c = e.c; return false; } return true; }); return c !== null ? c : (curCost[pid] || 0); };

    let cogs = 0, estLines = 0; const byProd = {};
    rows_('SaleItems').filter(i => saleDate[i.saleId]).forEach(i => {
      const qty = Number(i.qty) || 0; let cost;
      if (i.cogs !== '' && i.cogs != null && !isNaN(Number(i.cogs))) cost = Number(i.cogs);
      else { cost = qty * costAt(i.productId, saleDate[i.saleId]); estLines++; }
      cogs += cost;
      const b = byProd[i.productId] || (byProd[i.productId] = { name: i.name, qty: 0, revenue: 0, cogs: 0 });
      b.qty += qty; b.revenue += Number(i.lineTotal) || 0; b.cogs += cost;
    });
    const stockValue = round2_(rows_('Batches').reduce((a, b) => a + (Number(b.qtyRemaining) || 0) * (Number(b.unitCost) || 0), 0));
    const topProducts = Object.keys(byProd).map(k => { const b = byProd[k]; return { name: b.name, qty: b.qty, revenue: round2_(b.revenue), cogs: round2_(b.cogs), profit: round2_(b.revenue - b.cogs) }; })
      .sort((a, b) => b.profit - a.profit).slice(0, 10);

    const exp = rows_('Expenses').filter(e => inRange(e.date)).map(e => { e.date = String(e.date).slice(0, 10); return e; }).sort((a, b) => (a.date < b.date ? 1 : -1));
    const byCat = {}; let expenses = 0;
    exp.forEach(e => { const a = Number(e.amount) || 0; expenses += a; const k = e.category || 'Other'; byCat[k] = (byCat[k] || 0) + a; });

    revenue = round2_(revenue); cogs = round2_(cogs); expenses = round2_(expenses);
    const gross = round2_(revenue - cogs), net = round2_(gross - expenses);
    return {
      from: from, to: to, salesCount: sales.length, estLines: estLines, stockValue: stockValue,
      revenue: revenue, discount: round2_(discount), tax: round2_(tax),
      cogs: cogs, grossProfit: gross, grossMargin: revenue > 0 ? round2_(gross / revenue * 100) : 0,
      expenses: expenses, netProfit: net, netMargin: revenue > 0 ? round2_(net / revenue * 100) : 0,
      expensesByCategory: Object.keys(byCat).map(k => ({ category: k, amount: round2_(byCat[k]) })).sort((a, b) => b.amount - a.amount),
      topProducts: topProducts, expenseList: strip_(exp)
    };
  };

  API.saveExpense = e => tx(() => {
    if (!e || !/^\d{4}-\d{2}-\d{2}$/.test(String(e.date || ''))) throw new Error('Enter a valid date');
    const category = String(e.category || '').trim().replace(/\s+/g, ' ').slice(0, 60);
    if (!category) throw new Error('Category is required');
    const amount = round2_(e.amount);
    if (!(amount > 0)) throw new Error('Amount must be greater than zero');
    const rec = { date: e.date, category: category, description: String(e.description || '').trim().slice(0, 200), amount: amount };
    if (e.id) {
      const old = rows_('Expenses').find(r => r.id === e.id);
      if (!old) throw new Error('Expense not found');
      writeRow_('Expenses', old._row, Object.assign({}, old, rec));
      return { ok: true, id: old.id };
    }
    rec.id = nextId_('Expenses', 'E', 4); rec.createdAt = now_();
    append_('Expenses', [rec]);
    return { ok: true, id: rec.id };
  });

  API.deleteExpense = id => tx(() => {
    const e = rows_('Expenses').find(r => r.id === id);
    if (!e) throw new Error('Expense not found');
    deleteRow_('Expenses', e._row);
    return { ok: true };
  });

  API.renameExpenseCategory = (from, to) => tx(() => {
    rows_('Expenses').forEach(e => { if (e.category === from) setCell_('Expenses', e._row, 'category', to); });
    return { ok: true };
  });

  API.getExpenseCategories = () => tx(() => {
    if (!cache.Categories.length) append_('Categories', DEFAULT_EXPENSE_CATEGORIES.map(n => ({ name: n })));
    const seen = {}, out = [];
    const add = v => { const n = String(v == null ? '' : v).trim().replace(/\s+/g, ' '); if (n && !seen[n.toLowerCase()]) { seen[n.toLowerCase()] = true; out.push(n); } };
    rows_('Categories').forEach(r => add(r.name));
    rows_('Expenses').forEach(r => add(r.category));
    return out;
  });

  API.getAnalytics = (from, to, group) => {
    from = String(from || '').slice(0, 10); to = String(to || '').slice(0, 10);
    if (!from || !to || from > to) throw new Error('Choose a valid date range');
    const inRange = d => { const k = String(d).slice(0, 10); return k >= from && k <= to; };
    const d0 = new Date(+from.slice(0, 4), +from.slice(5, 7) - 1, +from.slice(8, 10)), d1 = new Date(+to.slice(0, 4), +to.slice(5, 7) - 1, +to.slice(8, 10));
    const days = Math.round((d1 - d0) / 864e5) + 1;
    group = ['day', 'month', 'year'].includes(group) ? group : 'day';
    if (group === 'day' && days > 400) group = 'month';
    if (group === 'month' && days > 365 * 30) group = 'year';
    const keyOf = d => { const k = String(d).slice(0, 10); return group === 'year' ? k.slice(0, 4) : group === 'month' ? k.slice(0, 7) : k; };
    const B = {}, bk = k => B[k] || (B[k] = { revenue: 0, cogs: 0, expenses: 0, orders: 0 }), keys = [];
    for (let d = new Date(d0); d <= d1; d = group === 'day' ? new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1) : group === 'month' ? new Date(d.getFullYear(), d.getMonth() + 1, 1) : new Date(d.getFullYear() + 1, 0, 1)) {
      const k = keyOf(ymd_(d)); if (keys[keys.length - 1] !== k) keys.push(k);
    }
    keys.forEach(bk);

    const sales = rows_('Sales').filter(s => inRange(s.date) && isLive_(s)), info = {};
    let revenue = 0, discount = 0;
    sales.forEach(s => { info[s.saleId] = s; const rev = Number(s.subtotal || 0) - Number(s.discount || 0); const b = bk(keyOf(s.date)); b.revenue += rev; b.orders++; revenue += rev; discount += Number(s.discount || 0); });

    const curCost = {}, cat = {}; rows_('Products').forEach(p => { curCost[p.id] = Number(p.cost) || 0; cat[p.id] = String(p.category || '').trim() || 'Uncategorized'; });
    const hist = {};
    rows_('Purchases').forEach(p => (hist[p.productId] = hist[p.productId] || []).push({ d: String(p.date), c: Number(p.unitCost) || 0 }));
    Object.keys(hist).forEach(k => hist[k].sort((a, b) => (a.d < b.d ? -1 : a.d > b.d ? 1 : 0)));
    const costAt = (pid, d) => { let c = null; (hist[pid] || []).some(e => { if (e.d <= d) { c = e.c; return false; } return true; }); return c !== null ? c : (curCost[pid] || 0); };

    let cogs = 0, units = 0; const byP = {}, byC = {};
    rows_('SaleItems').filter(i => info[i.saleId]).forEach(i => {
      const sale = info[i.saleId], qty = Number(i.qty) || 0, rev = Number(i.lineTotal) || 0;
      const cost = (i.cogs !== '' && i.cogs != null && !isNaN(Number(i.cogs))) ? Number(i.cogs) : qty * costAt(i.productId, String(sale.date));
      cogs += cost; units += qty; bk(keyOf(sale.date)).cogs += cost;
      const p = byP[i.productId] || (byP[i.productId] = { id: i.productId, name: i.name, qty: 0, revenue: 0, cogs: 0 });
      p.qty += qty; p.revenue += rev; p.cogs += cost;
      const cn = cat[i.productId] || 'Uncategorized', c = byC[cn] || (byC[cn] = { category: cn, qty: 0, revenue: 0, cogs: 0 });
      c.qty += qty; c.revenue += rev; c.cogs += cost;
    });

    let expenses = 0;
    rows_('Expenses').filter(e => inRange(e.date)).forEach(e => { const a = Number(e.amount) || 0; expenses += a; bk(keyOf(e.date)).expenses += a; });

    const trend = keys.map(k => { const b = B[k], gross = round2_(b.revenue - b.cogs); return { key: k, revenue: round2_(b.revenue), cogs: round2_(b.cogs), gross: gross, expenses: round2_(b.expenses), net: round2_(gross - b.expenses), orders: b.orders }; });
    const fin = o => ({ qty: o.qty, revenue: round2_(o.revenue), profit: round2_(o.revenue - o.cogs) });
    const products = Object.keys(byP).map(k => Object.assign({ id: byP[k].id, name: byP[k].name }, fin(byP[k]))).sort((a, b) => b.qty - a.qty);
    const categories = Object.keys(byC).map(k => Object.assign({ category: k }, fin(byC[k]))).sort((a, b) => b.revenue - a.revenue);
    revenue = round2_(revenue); cogs = round2_(cogs); expenses = round2_(expenses);
    const gross = round2_(revenue - cogs);
    return {
      from: from, to: to, group: group,
      summary: { revenue: revenue, cogs: cogs, gross: gross, expenses: expenses, net: round2_(gross - expenses), orders: sales.length, aov: sales.length ? round2_(revenue / sales.length) : 0, units: units, discount: round2_(discount) },
      trend: trend, products: products, categories: categories
    };
  };

  API.getProductBatches = pid => {
    const ctx = fifoCtx_(), p = rows_('Products').find(r => r.id === pid) || {};
    const list = (ctx.byProd[pid] || []).filter(b => b.qtyRemaining > 0);
    const tracked = list.reduce((a, b) => a + b.qtyRemaining, 0);
    return { name: p.name || '', stock: Number(p.stock) || 0, batches: strip_(list), value: round2_(list.reduce((a, b) => a + b.qtyRemaining * b.unitCost, 0)), untracked: Math.max(0, (Number(p.stock) || 0) - tracked) };
  };

  API.getInvoice = saleId => {
    const sale = rows_('Sales').find(s => s.saleId === saleId);
    if (!sale) throw new Error('Invoice not found');
    const items = rows_('SaleItems').filter(i => i.saleId === saleId).map(i => ({ saleId: i.saleId, productId: i.productId, name: i.name, qty: Number(i.qty), price: Number(i.price), lineTotal: Number(i.lineTotal) }));
    const base = Number(sale.subtotal) - Number(sale.discount);
    return { sale: clean_(sale), items: items, taxRate: base > 0 ? round2_(Number(sale.tax) / base * 100) : 0 };
  };

  API.getSales = () => strip_(rows_('Sales').slice(-500).reverse());

  API.cancelOrReturnSale = (saleId, action, note) => tx(() => {
    if (action !== 'Cancelled' && action !== 'Returned') throw new Error('Invalid action');
    const sale = rows_('Sales').find(s => s.saleId === saleId);
    if (!sale) throw new Error('Sale not found');
    if (!isLive_(sale)) throw new Error('This sale is already ' + sale.status);
    const items = rows_('SaleItems').filter(i => i.saleId === saleId);
    if (!items.length) throw new Error('No items found for this sale');

    const prods = {}; rows_('Products').forEach(p => prods[p.id] = p);
    const ctx = fifoCtx_(), batchById = {};
    Object.keys(ctx.byProd).forEach(k => ctx.byProd[k].forEach(b => batchById[b.batchId] = b));
    const allocs = rows_('SaleBatches').filter(a => a.saleId === saleId);
    allocs.forEach(a => a.rem = Number(a.qty) || 0);

    const type = action === 'Returned' ? 'RETURN' : 'CANCEL', moves = [], restocked = [], touched = {};
    items.forEach(i => {
      const p = prods[i.productId], qty = Number(i.qty) || 0;
      if (!p || !(qty > 0)) return;
      let left = qty;
      allocs.forEach(a => {
        if (left <= 0 || a.productId !== i.productId || a.rem <= 0) return;
        const b = batchById[a.batchId], q = Math.min(a.rem, left);
        if (!b) return;
        b.qtyRemaining += q; a.rem -= q; left -= q;
        if (b._row) ctx.dirty[b.batchId] = b;
      });
      if (left > 0) {
        const unit = (i.cogs !== '' && i.cogs != null && !isNaN(Number(i.cogs))) ? Number(i.cogs) / qty : (Number(p.cost) || 0);
        addBatch_(ctx, p, left, unit, saleId + ' ' + type);
      }
      const before = Number(p.stock); p.stock = before + qty; touched[p.id] = p;
      moves.push(logMove_(p, type, qty, before, p.stock, saleId));
      restocked.push({ name: p.name, qty: qty });
    });

    let refund = Number(sale.paid) || 0, balance = null;
    if (sale.customerId) {
      const c = rows_('Customers').find(x => x.id === sale.customerId);
      if (c) {
        const due = Number(sale.due) || 0, bal = Number(c.balance) || 0, reduce = Math.min(due, bal);
        refund += due - reduce; balance = round2_(bal - reduce);
        setCell_('Customers', c._row, 'balance', balance);
        setCell_('Customers', c._row, 'totalSpent', round2_(Math.max(0, (Number(c.totalSpent) || 0) - (Number(sale.total) || 0))));
      }
    }
    refund = round2_(refund);
    Object.keys(touched).forEach(id => setCell_('Products', touched[id]._row, 'stock', touched[id].stock));
    flush_(ctx); append_('StockMovements', moves);
    setCell_('Sales', sale._row, 'status', action);
    setCell_('Sales', sale._row, 'statusDate', now_());
    setCell_('Sales', sale._row, 'statusNote', String(note || '').trim().slice(0, 200));
    setCell_('Sales', sale._row, 'refund', refund);
    return { ok: true, saleId: saleId, status: action, restocked: restocked, refund: refund, balance: balance };
  });

  /* ================= Users, roles & login (accounts stored in localStorage) ================= */
  /* PINs are never stored: only a salted, iterated SHA-256 hash is kept. The signed-in user lives only in memory,
     and every data call below is checked against that user's role before it reaches the database. */
  const USERS_KEY = 'pos_users', LOCK_KEY = 'pos_login_lock';
  const ROLE_PERMS = {
    admin: ['*'],
    cashier: ['basic', 'dashboard', 'sell', 'customers', 'orders', 'inventory_view']
  };
  const FN_PERM = {
    getInitialData: 'basic', getDashboard: 'dashboard', checkout: 'sell',
    saveCustomer: 'customers', getCustomerHistory: 'customers', settleBalance: 'customers',
    getInvoice: 'orders', getSales: 'orders', cancelOrReturnSale: 'cancel',
    saveProduct: 'inventory_edit', deleteProduct: 'inventory_edit', getProductBatches: 'cost',
    saveSupplier: 'purchase', savePurchase: 'purchase',
    getProfitReport: 'profit', getAnalytics: 'profit',
    saveExpense: 'expenses', deleteExpense: 'expenses', renameExpenseCategory: 'expenses', getExpenseCategories: 'expenses'
  };
  let session = null;
  const can = p => !!session && !!ROLE_PERMS[session.role] && (ROLE_PERMS[session.role].includes('*') || ROLE_PERMS[session.role].includes(p));

  const SHA_K = [], SHA_H = [];
  (function () { let n = 2, c = 0; while (c < 64) { let pr = true; for (let d = 2; d * d <= n; d++) if (n % d === 0) { pr = false; break; } if (pr) { if (c < 8) SHA_H[c] = Math.floor((Math.sqrt(n) % 1) * 4294967296) | 0; SHA_K[c] = Math.floor((Math.cbrt(n) % 1) * 4294967296) | 0; c++; } n++; } })();
  function sha256(msg) {
    const bytes = new TextEncoder().encode(msg), l = bytes.length, total = (((l + 8) >> 6) + 1) << 6, buf = new Uint8Array(total);
    buf.set(bytes); buf[l] = 0x80; const dv = new DataView(buf.buffer); dv.setUint32(total - 4, (l * 8) >>> 0); dv.setUint32(total - 8, Math.floor(l * 8 / 4294967296));
    const H = SHA_H.slice(), W = new Int32Array(64);
    for (let o = 0; o < total; o += 64) {
      for (let i = 0; i < 16; i++) W[i] = dv.getUint32(o + i * 4);
      for (let i = 16; i < 64; i++) { const a = W[i - 15], b = W[i - 2]; W[i] = (W[i - 16] + (((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3)) + W[i - 7] + (((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10))) | 0; }
      let a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (let i = 0; i < 64; i++) {
        const t1 = (h + (((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7))) + ((e & f) ^ (~e & g)) + SHA_K[i] + W[i]) | 0;
        const t2 = ((((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10))) + ((a & b) ^ (a & c) ^ (b & c))) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0; H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
    }
    return H.map(v => (v >>> 0).toString(16).padStart(8, '0')).join('');
  }
  window.POS_SHA256 = sha256;
  const hashPin = (pin, salt) => { let h = sha256(salt + ':' + pin); for (let i = 0; i < 10000; i++) h = sha256(h + salt); return h; };
  const newSalt = () => { const a = new Uint8Array(16); if (window.crypto && crypto.getRandomValues) crypto.getRandomValues(a); else a.forEach((_, i) => a[i] = Math.random() * 256); return [...a].map(b => b.toString(16).padStart(2, '0')).join(''); };
  const readUsers = () => { try { const u = JSON.parse(localStorage.getItem(USERS_KEY)); return Array.isArray(u) ? u : []; } catch (e) { return []; } };
  const writeUsers = u => localStorage.setItem(USERS_KEY, JSON.stringify(u));
  const pubUser = u => ({ id: u.id, name: u.name, role: u.role });
  const cleanName = n => String(n || '').trim().replace(/\s+/g, ' ').slice(0, 40);
  const checkPin = p => { if (!/^\d{4,10}$/.test(String(p || ''))) throw new Error('PIN must be 4 to 10 digits'); };
  const needAdmin = () => { if (!can('settings')) throw new Error('Only an Admin can do this'); };
  const nextUid = us => 'U' + (us.reduce((m, u) => Math.max(m, parseInt(String(u.id).slice(1), 10) || 0), 0) + 1);
  const nameTaken = (us, name, exceptId) => us.some(u => u.id !== exceptId && u.name.toLowerCase() === name.toLowerCase());

  window.POS_AUTH = {
    can: p => can(p),
    hasUsers: () => readUsers().length > 0,
    users: () => readUsers().map(pubUser),
    current: () => session ? Object.assign({}, session) : null,
    setupAdmin(name, pin) {
      if (readUsers().length) throw new Error('Setup has already been done');
      name = cleanName(name); if (!name) throw new Error('Enter a name'); checkPin(pin);
      const salt = newSalt(); writeUsers([{ id: 'U1', name: name, role: 'admin', salt: salt, hash: hashPin(pin, salt), createdAt: now_() }]);
    },
    login(id, pin) {
      let L = {}; try { L = JSON.parse(localStorage.getItem(LOCK_KEY)) || {}; } catch (e) {}
      if (L.until && L.until > Date.now()) throw new Error('Too many wrong PINs. Try again in ' + Math.ceil((L.until - Date.now()) / 1000) + ' seconds');
      const u = readUsers().find(x => x.id === id);
      if (!u || hashPin(String(pin || ''), u.salt) !== u.hash) {
        L.n = (L.n || 0) + 1; if (L.n >= 5) { L.until = Date.now() + 30000; L.n = 0; }
        localStorage.setItem(LOCK_KEY, JSON.stringify(L)); throw new Error('Wrong PIN');
      }
      localStorage.removeItem(LOCK_KEY); session = pubUser(u); return pubUser(u);
    },
    logout() { session = null; },
    addUser(name, role, pin) {
      needAdmin(); name = cleanName(name); if (!name) throw new Error('Enter a name');
      if (!ROLE_PERMS[role]) throw new Error('Invalid role'); checkPin(pin);
      const us = readUsers(); if (nameTaken(us, name)) throw new Error('That name is already used');
      const salt = newSalt(); us.push({ id: nextUid(us), name: name, role: role, salt: salt, hash: hashPin(pin, salt), createdAt: now_() }); writeUsers(us);
    },
    updateUser(id, o) {
      needAdmin(); const us = readUsers(), u = us.find(x => x.id === id); if (!u) throw new Error('User not found');
      if (o.name !== undefined) { const n = cleanName(o.name); if (!n) throw new Error('Enter a name'); if (nameTaken(us, n, id)) throw new Error('That name is already used'); u.name = n; }
      if (o.role !== undefined && o.role !== u.role) {
        if (!ROLE_PERMS[o.role]) throw new Error('Invalid role');
        if (id === session.id) throw new Error('You cannot change your own role');
        if (u.role === 'admin' && us.filter(x => x.role === 'admin').length < 2) throw new Error('There must be at least one Admin');
        u.role = o.role;
      }
      if (o.pin) { checkPin(o.pin); u.salt = newSalt(); u.hash = hashPin(o.pin, u.salt); }
      writeUsers(us); if (id === session.id) session = pubUser(u);
    },
    deleteUser(id) {
      needAdmin(); const us = readUsers(), u = us.find(x => x.id === id); if (!u) throw new Error('User not found');
      if (id === session.id) throw new Error('You cannot delete the account you are using');
      if (u.role === 'admin' && us.filter(x => x.role === 'admin').length < 2) throw new Error('There must be at least one Admin');
      writeUsers(us.filter(x => x.id !== id));
    },
    changeOwnPin(oldPin, newPin) {
      if (!session) throw new Error('Please sign in'); checkPin(newPin);
      const us = readUsers(), u = us.find(x => x.id === session.id);
      if (!u || hashPin(String(oldPin || ''), u.salt) !== u.hash) throw new Error('Current PIN is wrong');
      u.salt = newSalt(); u.hash = hashPin(newPin, u.salt); writeUsers(us);
    }
  };

  /* ---------- Local call bridge (replaces google.script.run) – every call is permission-checked ---------- */
  const COST_KEYS = { cost: 1, unitCost: 1, cogs: 1 };
  const stripCost = o => { if (Array.isArray(o)) return o.map(stripCost); if (o && typeof o === 'object') { const c = {}; Object.keys(o).forEach(k => { if (!COST_KEYS[k]) c[k] = stripCost(o[k]); }); return c; } return o; };
  window.posCall = (fn, ...a) => ready.then(() => {
    if (!API[fn]) throw new Error('Unknown function: ' + fn);
    const need = FN_PERM[fn];
    if (!need) throw new Error('Not allowed');
    if (!session) throw new Error('Please sign in first');
    if (!can(need)) throw new Error('Your role (' + session.role + ') is not allowed to do this');
    if (window.POS_LICENSE && !window.POS_LICENSE.ok()) throw new Error((window.POS_LICENSE.message && window.POS_LICENSE.message()) || 'Access has expired – enter a license key to continue');
    return API[fn](...a);
  }).then(res => {
    if (can('cost')) return res;
    if (res && Array.isArray(res.purchases)) res = Object.assign({}, res, { purchases: [] });   // purchase rows reveal unit costs
    return stripCost(res);
  });

  /* ---------- Backup / restore (Admin only; includes users and expense categories) ---------- */
  async function exportBackup() {
    if (!can('settings')) throw new Error('Only an Admin can do this');
    await ready;
    const data = { app: 'pos-offline', version: 2, exportedAt: now_(), tables: {}, extra: { users: localStorage.getItem(USERS_KEY), categories: localStorage.getItem('pos_expense_categories'), business: localStorage.getItem('pos_business') } };
    Object.keys(SCHEMA).forEach(n => data.tables[n] = cache[n]);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
    a.download = 'pos-backup-' + now_().slice(0, 10) + '.json';
    document.body.appendChild(a); a.click(); a.remove();
  }
  async function importBackup(file) {
    if (!can('settings')) throw new Error('Only an Admin can do this');
    const data = JSON.parse(await file.text());
    if (!data || data.app !== 'pos-offline' || !data.tables) throw new Error('This is not a POS backup file');
    await ready;
    const names = Object.keys(SCHEMA), t = db.transaction(names, 'readwrite');
    names.forEach(n => { const s = t.objectStore(n); s.clear(); (data.tables[n] || []).forEach(r => s.put(r)); });
    await new Promise((res, rej) => { t.oncomplete = res; t.onerror = t.onabort = () => rej(t.error); });
    if (data.extra) {
      if (data.extra.users) localStorage.setItem(USERS_KEY, data.extra.users);
      if (data.extra.categories) localStorage.setItem('pos_expense_categories', data.extra.categories);
      if (data.extra.business) localStorage.setItem('pos_business', data.extra.business);
    }
    await loadAll();
  }
  window.POS_DB = { exportBackup, importBackup };

  document.addEventListener('DOMContentLoaded', () => {
    const foot = document.querySelector('.side-foot');
    if (foot) foot.innerHTML = '<span class="dot"></span><span>Offline · saved on this device</span>';
  });
  window.posRestore = async inp => {
    const f = inp.files[0]; if (!f) return;
    if (!confirm('Replace ALL current data (and users) with this backup?')) { inp.value = ''; return; }
    try { await importBackup(f); alert('Backup restored. Please sign in again.'); location.reload(); } catch (e) { alert(e.message); }
  };
})();